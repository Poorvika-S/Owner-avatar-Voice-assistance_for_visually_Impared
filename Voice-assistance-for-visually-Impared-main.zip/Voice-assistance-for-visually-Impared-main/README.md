# Virtual-Assistance-for-Visually-Impared
As a virtual assistant designed to help visually impaired people navigate around places and identify individuals in front of them.

# TEAM:  TECHNOTATVA 
TEAM LEADER:   

SHRIGOWRI S KULKARNI        |  https://github.com/shrigowrikulkarni

TEAM MATES:    

MANUPRIYA G B               | 

SOUMYA KALASAREDDY          | 

V SRI KRISHNA DEVA RAYUDU   |   https://github.com/potasticg
